<?php
/* Redirect to a different page in the current directory that was requested */
header("Location: studio/../member/index.php");
?>