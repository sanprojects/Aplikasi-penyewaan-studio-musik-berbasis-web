        <!-- Header -->
        <div class="header">
          <?php include 'data/header.php' ?>
        </div>
        <!-- Header -->


  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="bg-white col-md-12 col-12">
          <h3>Daftar Pemesanan Baru</h3>
          <div class="alert alert-danger" align="center">
              <b>Info!</b><br/><p style="font-size: 14px"> HARAP KONFIRMASI PEMESANAN STUDIO KEPADA PELANGGAN YANG BERSANGKUTAN DENGAN MELALU SMS ATAU TELEPON KEPADA PIHAK YANG MEMESAN STUDIO MUSIK</p>
          </div>
                    
                    <table class="table">
                      <thead class="thead-dark">

                        <tr align="center">
                        <th>No.</th> 
                        <th>Username</th>
                        <th>Tanggal Main</th>
                        <th>Jam Main</th>
                        <th>No Telpon</th>
                        <th>DP</th>
                        <th>Status</th>
                      </thead>
                      
            <?php
              include '/data/koneksi.php';
              $no= 0;
              $datas = mysqli_query($db,"select * from pemesanan where status='Disetujui' or status='Dibatalkan'");
              while($cc = mysqli_fetch_array($datas)){
              $no++;
            ?>
                      <tbody>
                             
                      <tr>
                        <td align="center"><?php echo $no;?></td>
                        <td align="center"><?php echo $cc['username']; ?></td>
                        <td align="center"><?php echo $cc['tanggal']; ?></td>
                        <td align="center"><?php echo $cc['jam']; ?></td>
                        <td align="center"><?php echo $cc['handphone']; ?></td>
                        <td align="center">
                          <span class="btn btn-success btn-sm"><?php echo $cc['dp']; ?></span>
                        </td>
                        <td align="center">
                          <span class="btn btn-success btn-sm"><?php echo $cc['status']; ?></span>
                        </td>
                      </tr>

                      <?php } ?>


                      </tbody>
                    </table>
                    </div>
                  </div>
                </div>
              </div><br><br><br><br><br><br><br>
              
      <!-- Footer -->
      <div class="footer">
       <?php include 'data/footer.php' ?>
      </div>
      <!-- Footer-->