<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Studio Musik Supernova</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

</head>
<body>
  <div class="header">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <b>SUPERNOVA</b>
      </a><a class="navbar-collapse" style="color: white">Login Area Admin</a>
    </div>
  </nav>
  </div>

<?php 
  session_start();
  error_reporting(0);
  if($_SESSION['status']=="login"){
    header("location:pesanan-baru");
  }
?>

  <div class="py-5 text-center" style="background-image: url('https://static.pingendo.com/cover-bubble-dark.svg');background-size:cover;">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-md-6 col-10 bg-white p-5">
          <h1 class="mb-4">Log in</h1>
          <form action="data/proses-login.php" method="post">
              <?php 
                if(isset($_GET['pesan'])){
                  if ($_GET['pesan']=="failed"){
                  echo '<div id="pesan" class="alert alert-danger" role="alert" align="center">'."Login Gagal! username atau password salah!".'</div>';
                  }elseif($_GET['pesan']=="logout"){
                  echo '<div id="pesan" class="alert alert-success" role="alert" align="center">'."Sukses! Anda Telah LogOut".'</div>';
                  }elseif($_GET['pesan']=="belum-login"){
                  echo '<div id="pesan" class="alert alert-danger" role="alert" align="center">'."Anda Belum Login! Silahkan Login Terlebih Dahulu!".'</div>';
                  }
                }
             ?>
            <div class="form-group" align="left">
              <label><b>Username : </b></label>
              <input type="text" class="form-control" placeholder="Enter Username" name="username"> </div>
            <div class="form-group" align="left">
              <label><b>Password : </b></label>
             <input type="password" class="form-control" placeholder="Password" name="password">
              <small class="form-text text-muted text-right"><br>
                
              </small> </div>
              <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!--Foooter-->
  <div class="footer">
  <div class="bg-dark">
    <div class="container">
      <div class="row">
        <!-- Footer Copyright-->
        <div class="row">
          <div class="col-md-12 mt-3">
            <p style="color:white">© Copyright 2020 Supernova Studio - All rights reserved. <br> <a href="https://wa.me/6281294493204" style="color:white"> Whatsapp : 6281294493204</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous" style=""></script>
</body>

  <?php
    
  ?>

</html>