    <!-- Header -->
    <div class="header">
      <?php include 'data/header.php' ?>
    </div>
    <!-- Header -->
    

  <!-- Bagian Konten -->
  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 p-4">
          <h3>Edit Data Pelanggan</h3>
          <hr>
          <!-- PHP Edit Data -->
            <?php
              include '/data/koneksi.php';
              $id = $_GET['id_user'];
              $datas = mysqli_query($db,"select * from user where id_user='$id'");
              while($d = mysqli_fetch_array($datas)){
            ?>
            <!--End Of PHP Edit Data -->
          <!-- Form Edit Data Pelanggan -->
          <form method="post" action="data/proses-edit.php">
            <div class="form-group"><input type="text" class="form-control" name="id_user" value="<?php echo $d['id_user'];?>" hidden readonly></div>
            <label class="control-label"><b>Nama Depan</b></label>
            <div class="form-group"><input type="text" class="form-control" name="nama_depan" value="<?php echo $d['nama_depan'];?>" required></div>
            <label class="control-label"><b>Nama Belakang</b></label>
            <div class="form-group"><input type="text" class="form-control" name="nama_belakang" value="<?php echo $d['nama_belakang'];?>"></div>
            <label class="control-label"><b>No Handphone</b></label>
            <div class="form-group"><input type="tel" class="form-control" name="handphone" value="<?php echo $d['handphone'];?>" required></div>
            <label class="control-label"><b>Alamat</b></label>
            <div class="form-group"><input type="text" class="form-control" name="alamat" value="<?php echo $d['alamat'];?>" required></div>
            <label class="control-label"><b>Username</b></label>
            <div class="form-group"><input type="text" class="form-control" name="username" value="<?php echo $d['username'];?>" readonly></div>
            <label class="control-label"><b>Password</b></label>
            <div class="form-group"><input type="password" id="pw" class="form-control" name="password" value="<?php echo $d['password'];?>" required>
            <input type="checkbox" onclick="showPW()"><b>Tampilkan Sandi</b></div>
            <button type="submit" onclick="return konfirmasi()" class="btn btn-primary">Edit Data</button>
          </form>
          <!--END Of Form Edit Data Pelanggan -->

          <!-- Fetch While-->
          <?php } ?>
          <!-- End of Fetch While-->

        </div>
      </div>
    </div>
  </div>
  <!-- Akhir Bagian Konten-->

      <!-- Footer -->
      <div class="footer">
       <?php include 'data/footer.php' ?>
      </div>
      <!-- Footer-->

      <script type="text/javascript" language="JavaScript">
            function konfirmasi()
            {
                tanya = confirm("Apakah Anda yakin ingin menyimpan perubahaan ?");
                if (tanya== true) return true;
                else return false; 
            }
      </script>

      <script type="text/javascript">
        function showPW() {
          var x = document.getElementById("pw");
        if (x.type === "password") {
          x.type = "text";
        } else {
          x.type = "password";
        }
        }
      </script>