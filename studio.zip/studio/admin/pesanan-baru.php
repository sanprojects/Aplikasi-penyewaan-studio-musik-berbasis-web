
        <!-- Header -->
        <div class="header">
          <?php include 'data/header.php' ?>
        </div>
        <!-- Header -->


  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="bg-white col-md-12 col-12">
          <h3>Daftar Pemesanan Baru</h3>
          <hr>

                    <table class="table">
                      <thead class="thead-dark">
                        <tr>
                        <th>No.</th> 
                        <th>Username</th> 
                        <th>Tanggal Main</th>
                        <th>Jam Main</th>
                        <th>No Telpon</th>
                        <th>Bukti Transfer</th>
                        <th>Status</th>
                        <th>AKSI</th>

                      </tr>
                      </thead>
                      
                      <tbody>



            <?php
              include '/data/koneksi.php';
              $datas = mysqli_query($db,"select * from pemesanan where status='Tertunda'");

              while($cc = mysqli_fetch_array($datas)){

              $no= 0; $no++;
            ?>         

                             
                      <tr>
                        <td><?php echo $no;?></td>
                        <td><?php echo $cc['username']; ?></td>
                        <td><?php echo $cc['tanggal']; ?></td>
                        <td><?php echo $cc['jam']; ?></td>
                        <td><?php echo $cc['handphone']; ?></td>
                        <td><a href="../member/verifikasi/<?php echo $cc['img'] ?>" target="_blank">Cek Bukti</a></td>

                        <td>
                          <span class="btn btn-success btn-sm"><?php echo $cc['status']; ?></span>
                        </td>

                        <td>
                            <a href="data/update-pesanan.php?id_pemesanan=<?php echo $cc['id_pemesanan']; ?>" onclick="return konfirmasiz()" class="btn btn-warning btn-sm" >Konfirmasi</a>
                            <a href="data/hapus-pesanan.php?id_pemesanan=<?php echo $cc['id_pemesanan']; ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm" >Hapus </a>
                        </td>
                      </tr>

                      <?php } ?>

                      </tbody>
                  </table>
        </div>
      </div>
    </div>
  </div>
            <br><br><br><br><br><br><br>

      <!-- Footer -->
      <div class="footer">
       <?php include 'data/footer.php' ?>
      </div>
      <!-- Footer-->


<script type="text/javascript" language="JavaScript">
$(document).ready(function() {
    $('#pesan').DataTable( {
        
    } );
     
} );

function konfirmasi()
{
    tanya = confirm("Anda yakin akan menghapus data ?");
    if (tanya== true) return true;
    else return false; 
} 

function konfirmasiz()
{
    tanya = confirm("Dengan meng-klik ini admin sudah memverifikasi bahwa pelanggan bersangkutan membayar DP");
    if (tanya== true) return true;
    else return false; 
} 
function konfirmasix()
{
    tanya = confirm("Dengan klik ini bahwa pelanggan bersangkutan sudah membayar lunas ?");
    if (tanya== true) return true;
    else return false; 
} 
</script>