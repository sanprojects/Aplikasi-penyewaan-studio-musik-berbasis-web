<?php 

    $data = [
        'phone' => '6287718690800',
        'body' => 'Anda telah berhasil melakukan Booking Studio Musik Supernova, Silahkan Melakukan Pembayaran DP dan melakukan upload bukti transfer / pembayaran ke nomor ini agar pesanan diverifikasi oleh admin',
    ];

    $json = json_encode($data);

    $url = 'https://eu2.chat-api.com/instance89978/message?token=b4k19lfw1633dal6';

    $option = stream_context_create(['http' => [
        'method' => 'POST',
        'header' => 'Content-type : application/json',
        'content' => $json
        ]
    ]);

    $result = file_get_contents($url, false, $option);
 ?>