<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data id yang di kirim dari url
$id = $_GET['id_pemesanan'];
echo $id;


 
 
// menghapus data dari database
$hasil = mysqli_query($db,"update pemesanan set dp='dibayar', status='Disetujui' where id_pemesanan='$id'") or die(mysqli_error());


// mengalihkan halaman kembali ke index.php
if(!$hasil){
	echo "gagal";
} else{
	header("location:../daftar-pemesanan.php");
}

 
?>