<?php

session_start();

include 'koneksi.php';
 
$username = mysqli_escape_string($db,$_POST['username']);
$password = mysqli_escape_string($db,$_POST['password']);

$login = "select * from admin where username='$username' and password='$password'";
$query = mysqli_query($db,$login);
$cek = mysqli_num_rows($query);
if($cek == 1 ){
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header("location:../pesanan-baru?pesan=welcome");
}else{
	header("location:../index?pesan=failed");
}
?>