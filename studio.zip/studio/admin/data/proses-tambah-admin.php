<?php 
	//melakukan koneksi ke database
	include 'koneksi.php';

	//menangkap data yang dikirim dari daftar.php
	$nama = $_POST['nama'];
	$nohp = $_POST['nohp'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	

	//proses input ke database
	$query = mysqli_query($db,"insert into admin(username, nama, handphone,password) values('$username','$nama','$nohp','$password')");
	if (!$query) {
		echo "gagal";
	}else{
		header("location:../data-administrator.php?pesan=success");
	}
	

 ?>