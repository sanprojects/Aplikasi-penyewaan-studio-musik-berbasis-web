<?php
	$db = mysqli_connect("localhost","root","","supernova");
	if (!$db) {
		echo "Koneksi Gagal!";
	}
?>