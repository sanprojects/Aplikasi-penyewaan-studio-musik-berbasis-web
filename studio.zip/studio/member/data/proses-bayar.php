		<?php 
		include 'koneksi.php';

		$id = $_POST['id_user'];


		if($_POST['upload']){
			$ekstensi_diperbolehkan	= array('png','jpg','jpeg');
			$nama = $_FILES['file']['name'];
			$x = explode('.', $nama);	
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];	
 
			if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
				if($ukuran < 1044070){			
					move_uploaded_file($file_tmp, '../verifikasi/'.$nama);
					$query = mysqli_query($db,"update pemesanan set img='$nama' where id_pemesanan='$id'");
					if($query){
						echo "<script type='text/javascript'>alert('Data Berhasil Disimpan');window.location = '../riwayat';</script>";
					}else{
						echo "<script type='text/javascript'>alert('Data Gagal Disimpan');window.location = '../bayar';</script>";
					}
				}else{
					echo "<script type='text/javascript'>alert('Ukuran File Terlalu Besar');window.location = '../bayar';</script>";
				}
			}else{
				echo "<script type='text/javascript'>alert('ekstensi File Yang Di Upload Tidak Diperbolehkan');window.location = '../bayar
				';</script>";
			}
		}
		?>