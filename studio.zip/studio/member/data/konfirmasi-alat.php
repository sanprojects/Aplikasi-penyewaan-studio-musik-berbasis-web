<?php
include 'koneksi.php';
$a=$_POST['id_jadwal'];
$idharga=$_POST['id_harga'];
$iduser=$_POST['id_user'];
$b=$_POST['username'];
$d=$_POST['tanggalz'];
$e=$_POST['jams'];
$f=$_POST['harga'];
$g=$_POST['alamat'];
$h=$_POST['handphone'];

mysqli_query($db,"insert into pemesanan(id_user,id_harga,id_jadwal,username,alamat,handphone,tanggal,jam,harga,status)values('$iduser','$idharga','$a','$b','$g','$h','$d','$e','$f','Tertunda')");

echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('pemesanan sudah terkirim, silahkan melakukan pembayaran dan melakukan verifikasi agar pesanan dapat di proses!')
    window.location.href='../riwayat';
    </SCRIPT>");

?>