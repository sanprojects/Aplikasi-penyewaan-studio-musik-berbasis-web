<!DOCTYPE html>
<html>


<!-- SESSION -->
<?php 
  session_start();
  if($_SESSION['status']!="login"){
  header("location:index?pesan=belum-login");
  }
?>
<!-- SESSION -->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://static.pingendo.com/bootstrap/bootstrap-4.3.1.css">

  <?php
    include 'koneksi.php';
      $data = mysqli_query($db,"select * from profile");
      while($d = mysqli_fetch_array($data)){
      ?>
  <title>Member Panel Studio <?php echo $d['nama_studio'];?></title>

  <?php } ?>


<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>

<body>
  <!-- Navigasi Bar Mulai-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container"> <a class="navbar-brand" href="index.php">
        <b> SUPERNOVA</b>
      </a>
        <ul class="navbar-nav mr-auto">
          <li class="nav-item"> <a class="navbar-collapse" style="color: white">Member Panel</a> </li>
        </ul>
       <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse" data-target="#navbar11">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbar11">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item"></li>
        </ul>
        <a class="btn btn-primary" href="data/proses-logout.php">Keluar</a>
      </div>
    </div>
  </nav>
  <!-- Navigasi Bar End-->

<div class="wrapper">
  <!-- Navbar Menu Mulai -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-light">
    <div class="container">
      <div class="row">
        <div class="nav nav-tabs">
              <div class="col-4 col-md"><p align="center"><a href="home.php" class="nav-link"  ><i class="fa fa-home"></i><span><br>Home</span></a></p></div>
              <div class="col-4 col-md"><p align="center"><a href="about.php" class="nav-link" ><i class="fa fa-user-circle"></i><span><br>About</span></a></p></div>
              <div class="col-4 col-md"><p align="center"><a href="pemesanan.php" class="nav-link" ><i class="fa fa-book"></i><span><br>Pemesanan</span></a></p></div>
              <div class="col-4 col-md"><p align="center"><a href="edit-profile.php" class="nav-link" ><i class="fa fa-cog"></i><span><br>Edit Profile</span></a></p></div>
              <div class="col-4 col-md"><p align="center"><a href="riwayat.php" class="nav-link" ><i class="fa fa-book"></i><span><br>History<br>Pemesanan</span></a></p></div>
              <div class="col-4 col-md"><p align="center"><a href="ketentuan.php" class="nav-link" ><i class="fa fa-info-circle"></i><span><br>Ketentuan<br>Pemakaian</span></a></p></div>
        </div>
      </div>
    </div>
  </nav>
  <!-- Akhir dari Navbar Menu Mulai -->