<?php 
	//melakukan koneksi ke database
	include 'koneksi.php';

	//menangkap data yang dikirim dari daftar.php
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$alamat = $_POST['alamat'];
	$nohp = $_POST['nohp'];
	$username = $_POST['username'];
	$password = $_POST['password'];

	//proses input ke database
	$query = mysqli_query($db,"insert into user(nama_depan, nama_belakang, handphone, alamat, username, password) values('$fname','$lname','$nohp','$alamat','$username','$password')");

	header("location:../index.php?pesan=success")

 ?>