
  <div class="header">
    <?php include 'data/header.php'?>
          <!-- PHP Edit Data -->
            <?php
              include '/data/koneksi.php';
              $user = $_SESSION['username'];
              //$datas = mysqli_query($db,"select * from user where username='$_SESSION[username]'");
              //while($d = mysqli_fetch_array($datas)){
            ?>
            <!--End Of PHP Edit Data -->
          <!-- Fetch While-->
          <?php //} ?>
          <!-- End of Fetch While-->
  </div>
  <?php
      
      function DateToIndo($date) { // fungsi atau method untuk mengubah tanggal ke format indonesia
     // variabel BulanIndo merupakan variabel array yang menyimpan nama-nama bulan
      $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
      $tahun = substr($date, 0, 4); // memisahkan format tahun menggunakan substring
      $bulan = substr($date, 5, 2); // memisahkan format bulan menggunakan substring
      $tgl   = substr($date, 8, 2); // memisahkan format tanggal menggunakan substring
      
      $result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;
      return($result);
      }

        $HariIndo = array(1=>"Senin", "Selasa", "Rabu", "Kamis","Jumat","Sabtu","Minggu");
        $hari = $HariIndo[date("N")];

      $sekarang = $hari.", ".(DateToIndo( date("Y-m-d")));

      date_default_timezone_set('Asia/Jakarta');
      $jam = date('G');

      $tanggal=mysqli_real_escape_string($db,$sekarang);
    ?>

  <!-- Bagian Konten -->
  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="card p-2">
          <h4>Halo, Selamat Datang <b><?php echo $user ?></b> <i class="fa fa-smile-o"></i></h4> 
          <hr><br>
          <center><h5><b>Jam yang sudah dibooking</b></h5></center>
          <!-- Form Edit Data Pelanggan -->
          <p></p>
            <table class="table">
                      <thead class="thead-dark">

                        <tr align="center">
                        <th>No.</th> 
                        <th>Username</th>
                        <th>Tanggal Main</th>
                        <th>Jam Main</th>
                      </thead>
                      
            <?php
              include '/data/koneksi.php';
              $no= 0;
              $datas = mysqli_query($db,"select * from pemesanan where tanggal='$tanggal' AND status='Disetujui'");
              while($cc = mysqli_fetch_array($datas)){
              $no++;
            ?>
                      <tbody>
                      <tr>
                        <td align="center"><?php echo $no;?></td>
                        <td align="center"><?php echo $cc['username']; ?></td>
                        <td align="center"><?php echo $cc['tanggal']; ?></td>
                        <td align="center"><?php echo $cc['jam']; ?></td>
                      </tr>

                      <?php } ?>


                      </tbody>
                    </table>
          <!--END Of Form Edit Data Pelanggan -->



        </div>
      </div>

        <div class="col-md-3">
          <div class="card p-2">
          <?php include 'data/menu-kanan.php' ?>
          </div>
        </div>

    </div>
    </div>
  </div>
  <!-- Akhir Bagian Konten-->

  <!--Foooter-->
  <div class="footer">
      <?php include 'data/footer.php'?>
  </div>
  <!--Foooter-->