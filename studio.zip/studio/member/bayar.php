<!-- Header -->
<div class="header">
  <?php include 'data/header.php' ?>
</div>
<!-- Header -->
  <?php
  $id = $_GET['id_pemesanan'];
  ?>

  <div class="py-3">
    <div class="container-fluid dashboard-content ">
                    <!-- ============================================================== -->
                    <!-- pageheader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                    <!-- ============================================================== -->
                    <!-- basic table  -->
                    <!-- ============================================================== -->
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <h3 class="card-header"></h3>
                            <div class="card-body">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                  <div class="card">
                    <center><h3 class="card-header">Upload Bukti Verifikasi</h3></center>
            
          <!-- PHP Edit Profile -->
            <?php
              //Fetch Harga
              $profile = mysqli_query($db,"select * from harga where id_harga='1'");
              while($d = mysqli_fetch_array($profile)){
                
              //Fetch Harga
            ?>
          <!--End Of PHP Edit Profile -->
                    <div class="card-body">
                      <form id="validationform" method="post" enctype="multipart/form-data" action="data/proses-bayar.php">
                        <div class="form-group row">
                          <label class="col-12 col-sm-3 col-form-label text-sm-left">Harga Sewa / Jam</label>
                          <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" name="id_user" class="form-control" value="<?php echo $id ?>" hidden>
                            <input type="text" name="harga" class="form-control" value="Rp.<?php echo $d['harga'];?>" disabled>
                          </div>
                        </div>
          <!-- Harga-->
            <?php } ?>
          <!-- Harga-->

          <!-- PHP Edit Profile -->
            <?php 
            $rekening = mysqli_query($db,"select * from about where id_about='3'");
            while($d = mysqli_fetch_array($rekening)){
            ?>
          <!--End Of PHP Edit Profile -->
                        <div class="form-group row">
                          <label class="col-12 col-sm-3 col-form-label text-sm-left">No Rekening Admin</label>
                          <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" name="harga_ex" class="form-control" value="<?php echo $d['isi'] ?>" disabled>
                          </div>
                        </div>
          <!-- Rekening -->
            <?php } ?>
          <!-- Rekening -->
                        <div class="form-group row">
                          <label class="col-12 col-sm-3 col-form-label text-sm-left">Biaya DP</label>
                          <div class="col-12 col-sm-8 col-lg-6">
                            <input type="text" required="" name="nama" class="form-control" value="Rp.10000" disabled>
                          </div>
                        </div>
                        <div class="form-group row">
                          <label class="col-12 col-sm-3 col-form-label text-sm-left">Upload Bukti Transfer</label>
                          <div class="col-12 col-sm-8 col-lg-6">
                            <input type="file" name="file" id="img" class="form-control">
                          </div>
                        </div>
                        <div class="form-group row text-center">
                          <div class="col col-sm-10 col-lg-9 offset-sm-1 offset-lg-0">
                            <input type="submit" class="btn btn-space btn-primary" value="Simpan" name="upload">
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                            </div>
                        </div>
                    </div>
                  </div>
  </div>
  


      <!-- Footer -->
      <div class="footer">
       <?php include 'data/footer.php' ?>
      </div>
      <!-- Footer-->