  <div class="header">
    <?php include 'data/header.php'?>
          <!-- PHP Edit Data -->
            <?php
              include '/data/koneksi.php';
              $isi = mysqli_query($db,"select isi from about where id_about='2'");
              $isi = mysqli_fetch_row($isi);
              $isi = $isi[0];

              $nama = mysqli_query($db,"select nama_studio from profile");
              $nama = mysqli_fetch_row($nama);
              $nama = $nama[0];
              //while($d = mysqli_fetch_array($datas)){
            ?>
            <!--End Of PHP Edit Data -->
          <!-- Fetch While-->
          <?php //} ?>
          <!-- End of Fetch While-->
  </div>

  <!-- Bagian Konten -->
  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="card p-2">
          <center><b><h4>Ketentuan Studio Musik <?php echo $nama ?></b></h4> </center>
          <hr>

          <!-- Form Edit Data Pelanggan -->
          <p><?php echo $isi ?></p>
          <!--END Of Form Edit Data Pelanggan -->



        </div>
      </div>

        <div class="col-md-3">
          <div class="card p-2">
          <?php include 'data/menu-kanan.php' ?>
          </div>
        </div>

    </div>
    </div>
  </div>
  <!-- Akhir Bagian Konten-->

  <!--Foooter-->
  <div class="footer">
      <?php include 'data/footer.php' ?>
  </div>
  <!--Foooter-->