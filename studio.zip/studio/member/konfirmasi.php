<?php
  include '/data/koneksi.php';
  $id_harga=$_POST['idharga'];
  $id_jadwal=$_POST['id'];
  $tanggalz=$_POST['tanggalz'];
  $harga=$_POST['harga'];
  $jams=$_POST['jamz'];
?>

  <div class="header">
    <?php include 'data/header.php' ?>
  </div>

  <!-- Bagian Konten -->
  <div class="py-3">
    <div class="container">
      <div class="card">
      <div class="row">
        <div class="col-lg-8 p-4">
          <h3><b>Konfirmasi Pemesanan</b></h3>
          <hr>
          
          <!-- PHP Edit Data -->
            <?php
              include '/data/koneksi.php';
              $datas = mysqli_query($db,"select * from user where username='$_SESSION[username]'");
              while($d = mysqli_fetch_array($datas)){
            ?>
          <!--End Of PHP Edit Data -->


            
          <!-- Form Edit Data Pelanggan -->
          <form method="POST" action="data/proses-konfirmasi">
            <div class="form-group"><input type="text" class="form-control" name="id_harga" value="<?php echo"$id_harga";?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="id_user" value="<?php echo $d['id_user'];?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="id_jadwal" value="<?php echo $id_jadwal;?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="alamat" value="<?php echo $d['alamat'];?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="username" value="<?php echo $d['username'];?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="handphone" value="<?php echo $d['handphone'];?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="tanggalz" value="<?php echo $tanggalz;?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="jams" value="<?php echo $jams;?>" hidden readonly></div>
            <div class="form-group"><input type="text" class="form-control" name="harga" value="<?php echo $harga;?>" hidden readonly></div>
            <label class="control-label"><b>Nama Pemesan :</b></label>
            <p><?php echo $d['nama_depan'];?> <?php echo $d['nama_belakang'];?></p>
            <label class="control-label"><b>No Handphone Aktif : </b></label>
            <p><?php echo $d['handphone'];?></p>
            <label class="control-label"><b>Tanggal Main : </b></label>
            <p><?php echo $tanggalz?></p>
            <label class="control-label"><b>Jam Main     : </b></label>
            <p><?php echo $jams?></p>
            <label class="control-label"><b>Harga        :</b></label>
            <p><?php echo $harga?></p>
            <br><button type="submit" class="btn btn-primary">Pesan</button>
          </form>
          <!--END Of Form Edit Data Pelanggan -->

          <!-- Fetch While-->
          <?php } ?>
          <!-- End of Fetch While-->

        </div>
            <div class="col-lg-4 p-4">
              <h3><b><center>Info!</center></b></h3>
              <hr>
              <div class="alert alert-danger">
                    Anda hanya dapat melakukan pemesanan sekali, anda tidak dapat mengedit, tetapi jika anda ingin memesan ulang anda dapat menghapus pesanan, dan jika anda ragu dengan pesanan anda bisa klik tombol batal di bawah, dan ulangi pemesanan
            </div>

        </div>
        </div>
      </div>
    </div>
    </div>
  </div>
  <!-- Akhir Bagian Konten-->

  <!--Foooter-->
  <div class="footer">
      <?php include 'data/footer.php' ?>
  </div>
  <!--Foooter-->