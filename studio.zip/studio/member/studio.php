<!-- Header -->
<div class="header">
  <?php include 'data/header.php' ?>
</div>
<!-- Header -->


<div class="py-5">
    <div class="container">
    <div class="card">
      <div class="row">
        <div class="text-center mx-auto col-md-12">
          <br>
          <h1 class="mb-4">Tarif Rental Studio Supernova</h1><hr>
        </div>
      </div>
      <div class="row d-flex justify-content-around">
        <div class="col-lg-5 px-1  py-1 bg-white d-flex flex-column mb-3">
          <div class="card p-3">
          <h3 class="pb-3 border-bottom">Rental Studio Musik</h3>
          <h3> <b>Rp40.000,- / Jam</b></h3>
          <p class="pb-3 border-bottom">Layanan Jasa Penyewaan Alat Musik ditempat, Sistem Penyewaannya menggunakan harga perjam, cocok digunakan untuk pengguna yang ingin latihan band.</p>
          <ul class="text-lg-right list-unstyled">
            <!--<li class="mb-1">One</li>-->
          </ul> <a class="btn btn-primary mt-auto btn-block" href="studio.php" style="background-color: #c65353">Pesan Sekarang!</a>
        </div>
        </div>
        <div class="col-lg-5 px-1  py-1 bg-white d-flex flex-column mb-3">
          <div class="card p-3">
          <h3 class="pb-3 border-bottom">Rental Alat Band</h3>
          <h3> <b>Rp1.300.000,- / Hari</b></h3>
          <p class="pb-3 border-bottom">Layanan Jasa Penyewaan Alat Band untuk dibawa keluar Rungan, seperti pengguna yang ingin melakukan pentas Band disekolah atau acara khusus.</p>
          <ul class="text-lg-right list-unstyled">
            <!--<li class="mb-1">One</li>-->
          </ul> <a class="btn btn-primary mt-auto btn-block" href="alat.php" style="background-color: #c65353">Pesan Sekarang!</a>
        </div>
        </div>
      </div>
      </div>
    </div>
  </div>


  <!-- Footer -->
  <div class="footer">
   <?php include 'data/footer.php' ?>
  </div>
  <!-- Footer-->