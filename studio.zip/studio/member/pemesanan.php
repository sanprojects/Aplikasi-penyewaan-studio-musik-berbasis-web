<!-- Header -->
<div class="header">
  <?php include 'data/header.php' ?>
</div>
<!-- Header -->


  <div class="py-3">
    <?php
      
      function DateToIndo($date) { // fungsi atau method untuk mengubah tanggal ke format indonesia
     // variabel BulanIndo merupakan variabel array yang menyimpan nama-nama bulan
      $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
      $tahun = substr($date, 0, 4); // memisahkan format tahun menggunakan substring
      $bulan = substr($date, 5, 2); // memisahkan format bulan menggunakan substring
      $tgl   = substr($date, 8, 2); // memisahkan format tanggal menggunakan substring
      
      $result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;
      return($result);
      }

        $HariIndo = array(1=>"Senin", "Selasa", "Rabu", "Kamis","Jumat","Sabtu","Minggu");
        $hari = $HariIndo[date("N")];

      $sekarang = $hari.", ".(DateToIndo( date("Y-m-d")));

      date_default_timezone_set('Asia/Jakarta');
      $jam = date('G');

    ?>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h3 class="mb-3">
            <b>Booking Studio</b></h3>
          <hr>

                      <!--Menampilkan Tanggal dan Waktu-->
                      <?php 
                      include '/data/koneksi.php';?>
                      <?php
                      ?>
                      Keterangan Waktu Booking : <?php if(empty($_POST['tgl'])){
                        echo $sekarang;
                        }?>
                      <!--Menampilkan Tanggal dan Waktu-->
<br><br>
<div class="table-responsive">
  <table class="table table-striped">
                              
      <thead class="thead-dark">
      <tr>
      <th>Jam</th>
      <th>Harga</th>
      <th>Status</th>
      </thead>
      <tbody>

      <?php
        $tanggal=mysqli_real_escape_string($db,$sekarang);
        $a=mysqli_query($db,"select jadwal.id_jadwal,jadwal.jam,jadwal.jams, harga.harga,harga.id_harga from jadwal,harga WHERE jadwal.id_harga=harga.id_harga order by jadwal.id_jadwal asc");
      
        while($b=mysqli_fetch_array($a)){
        $querys="select pemesanan.id_jadwal,pemesanan.status,pemesanan.tanggal,pemesanan.jam,jadwal.id_jadwal,jadwal.jams from pemesanan,jadwal WHERE tanggal='$tanggal' AND pemesanan.id_jadwal=jadwal.id_jadwal AND pemesanan.id_jadwal='$b[id_jadwal]'";

        $result=mysqli_query($db,$querys);
        $z=mysqli_fetch_array($result);
        ?>

        <tr>
          <td><?php echo $b['jams'] ?></td>
          <td ><?php echo $b['harga'] ?></td>
          <td><?php
        if($z['status']=='Tertunda'){
      ?>


  <form action="konfirmasi" method="POST">
   <input type="hidden" name="idharga" value="<?php echo $b['id_harga'];?>">
      <input type="hidden" name="id" value="<?php echo $b['id_jadwal'];?>">
      <input type="hidden" name="tanggalz" value="<?php echo $tanggal;?>">
      <input type="hidden" name="harga" value="<?php echo $b['harga'];?>">
      <input type="hidden" name="jamz" value="<?php echo $b['jams'];?>">
      <input type="submit" value="Pending" class="btn btn-warning cdz">

      </form>

      <?php
        }
          else if($z['tanggal']==$tanggal AND $b['id_jadwal']==$z['id_jadwal']){
           echo "<button type='button' class='btn btn-danger cdz'>Booked</button>";
           ?>
      <?php     
      }
      else if($b['jam']<=$jam){
          echo "<button type='button' class='btn btn-warning cdz'>Disable</button>";

            ?>
      <?php  
      }
      else{
      ?>  

  <form action="konfirmasi" method="POST">
   <input type="hidden" name="idharga" value="<?php echo $b['id_harga'];?>">
      <input type="hidden" name="id" value="<?php echo $b['id_jadwal'];?>">
      <input type="hidden" name="tanggalz" value="<?php echo $tanggal;?>">
      <input type="hidden" name="harga" value="<?php echo $b['harga'];?>">
      <input type="hidden" name="jamz" value="<?php echo $b['jams'];?>">
      <input type="submit" value="Pesan" class="btn btn-primary">
      </form>


      <?php } ?>


    </td>
    </tr>

        <?php } ?>

        </tbody>
        </table>
        </div>
        </div>
      </div>
    </div>
  </div>
  


      <!-- Footer -->
      <div class="footer">
       <?php include 'data/footer.php' ?>
      </div>
      <!-- Footer-->

    <!-- JAM -->
    <script>
      $(document).ready(function () {
        var date = new Date();
        var currentMonth = date.getMonth();
        var currentDate = date.getDate();
        var currentYear = date.getFullYear();
      $('#datepicker').datepicker({ dateFormat: 'DD' });
      });
    </script>
    <!-- JAM -->