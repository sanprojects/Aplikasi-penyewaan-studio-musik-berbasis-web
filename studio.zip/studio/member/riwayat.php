
<!-- Header -->
<div class="header">
  <?php include 'data/header.php' ?>
</div>
<!-- Header -->

<div class="container">
  <div class="row">
    <div class="col-md-12">
      <br><h3 class="mb-3"><b>Riwayat Pemesanan</b></h3>
          <hr>
      <div class="table-responsive">         
        <table id="pesan" class="table table-striped">
          <thead class="thead-dark">
          <tr>
          <th>No.</th> 
          <th>Username</th>
          <th>Tanggal main</th>
          <th>Jam main</th>
          <th>No telpon</th>
          <th>Status</th>
          <th>AKSI</th></tr>
          </thead>
            <tbody>

            <?php
              include '/data/koneksi.php';
              $no=0;
              $datas = mysqli_query($db,"select * from pemesanan where username='$_SESSION[username]'");
              while($cc = mysqli_fetch_array($datas)){
                           $no++;
            ?>

                            <tr>
                              <td><?php echo $no;?></td>
                              <td><?php echo $cc['username'];?></td>
                              <td><?php echo $cc['tanggal'];?></td>
                              <td><?php echo $cc['jam'];?></td>
                              <td><?php echo $cc['handphone'];?></td>
                              <td>
                                <?php
                              if(($cc['status']=='Disetujui')){?>
                              <span class="btn btn-success btn-sm"><?php echo $cc['status']; ?></span>



                              <?php
                              }elseif(($cc['status']=='Dibatalkan')){
                                ?>
                              <span class="btn btn-danger btn-sm"><?php echo $cc['status']; ?></span>
                              <?php
                              }
                              
                              elseif(($cc['status']=='Tertunda')){
                                ?>
                              <span class="btn btn-warning btn-sm" rel="popovers" id='el3' data-content="silahkan tunggu kurang lebih 10-15 menit sampai admin menkonfirmasi pesanan anda" title="info"><?php echo $cc['status']; ?></span>
                              <?php
                              }
                              ?>
                              </td>

                              <td>
                             
                              <?php
                              if(($cc['status']=='Tertunda')){?>
                                  <a href="bayar.php?id_pemesanan=<?php echo $cc['id_pemesanan']; ?>" class="btn btn-primary btn-sm" >Bayar</a>
                                  <a href="data/batal-pesanan.php?id_pemesanan=<?php echo $cc['id_pemesanan']; ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm" >Batalkan</a>
                                <?php
                              }elseif(($cc['status']=='Disetujui')){
                                ?>
                                <a href="data/batal-pesanan.php?id_pemesanan=<?php echo $cc['id_pemesanan']; ?>" onclick="return konfirmasi()" class="btn btn-danger btn-sm" >Batalkan</a>

                              <?php
                              }
                              ?>
                            
                              </td>
                          </tr>

                              <?php } ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript" language="JavaScript">
$(document).ready(function() {
    $('#pesan').DataTable( {
        
    } );
     
} );

function konfirmasi()
{
    tanya = confirm("Anda yakin akan membatalkan pesanan ?");
    if (tanya== true) return true;
    else return false; 
} 

</script>
  
    <!-- Script Pop Over Status di Riwayat Pemesanan Member -->
<script>
        $(function ()
        { $("#example").popover();
            $("#el3").popover();
        });
        function showPopup() {
            $('#el3').popover('show')
        }
        function hidePopup() {
            $('#el3').popover('hide')
        }
</script>
    <!-- Script Pop Over Status di Riwayat Pemesanan Member -->
<br><br><br><br><br><br><br><br><br><br>


<!-- Footer -->
<div class="footer">
 <?php include 'data/footer.php' ?>
</div>
<!-- Footer-->

