<!-- Header -->
<div class="header">
  <?php include 'data/header.php' ?>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css" type="text/css"/>
  <script src="http://code.jquery.com/jquery-1.10.2.js" type="text/javascript"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js" type="text/javascript"></script>
</div>
<!-- Header -->

<?php
function DateToIndo($date) { // fungsi atau method untuk mengubah tanggal ke format indonesia
   // variabel BulanIndo merupakan variabel array yang menyimpan nama-nama bulan
    $BulanIndo = array("Januari", "Februari", "Maret",
               "April", "Mei", "Juni",
               "Juli", "Agustus", "September",
               "Oktober", "November", "Desember");
  
    $tahun = substr($date, 0, 4); // memisahkan format tahun menggunakan substring
    $bulan = substr($date, 5, 2); // memisahkan format bulan menggunakan substring
    $tgl   = substr($date, 8, 2); // memisahkan format tanggal menggunakan substring
    
    $result = $tgl . " " . $BulanIndo[(int)$bulan-1] . " ". $tahun;
    return($result);
}
  ?>


<div class="py-5">
    <div class="container">
      <div class="card p-5">
        <div class="row">
        <div class="col-md-12">
          <h3 class="mb-3">
            <b>Pemesanan Alat</b></h3>
          <hr>

        
<script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
</script>
        <form method="post" action="data/konfirmasi-alat.php">
            <div class="form-group"> <!-- Date input -->
            <label class="control-label" for="date">Date</label>
            <input class="form-control" id="datepicker" name="date" placeholder="MM/DD/YYYY" type="text"/>
          
            </div>
            <div class="form-group"> <!-- Submit button -->
            <button class="btn btn-primary " name="submit" type="submit">Submit</button>
            </div>
        </form>
                              <?php ?>
                      Keterangan Waktu Booking : <?php if(empty($_POST['date'])){
                  
                         echo(DateToIndo( date("Y-m-d")));
                        }else{
                         echo(DateToIndo("$_POST[date]"));
                          }?> 
        </div>
      </div>
    </div>
  </div>
</div>


  <!-- Footer -->
  <div class="footer">
   <?php include 'data/footer.php' ?>
  </div>
  <!-- Footer-->