  <div class="header">
    <?php include 'data/header.php'?>
          <!-- PHP Edit Data -->
          
            <?php
              include '/data/koneksi.php';
              $datas = mysqli_query($db,"select isi from about where id_about='1'");
              $datas = mysqli_fetch_row($datas);
              $datas = $datas[0];

              $dotos = mysqli_query($db,"select nama_studio from profile");
              $dotos = mysqli_fetch_row($dotos);
              $dotos = $dotos[0];
              //while($d = mysqli_fetch_array($datas)){
            ?>
            <!--End Of PHP Edit Data -->
          <!-- Fetch While-->
          <?php //} ?>
          <!-- End of Fetch While-->
  </div>

  <!-- Bagian Konten -->
  <div class="py-3">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="card p-2">
          <center><b><h4>Tentang Studio Musik <?php echo $dotos ?></b></h4> </center>
          <hr>

          <!-- Form Edit Data Pelanggan -->
          <p><?php echo $datas ?></p>
          <!--END Of Form Edit Data Pelanggan -->



        </div>
      </div>

        <div class="col-md-3">
          <div class="card p-2">
          <?php include 'data/menu-kanan.php' ?>
          </div>
        </div>

    </div>
    </div>
  </div>
  <!-- Akhir Bagian Konten-->

  <!--Foooter-->
  <div class="footer">
      <?php include 'data/footer.php' ?>
  </div>
  <!--Foooter-->